import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import type { TenantStatus, UserStatus } from "@/lib/api/types";

type Status = TenantStatus | UserStatus;

const STATUS_CONFIG: Record<Status, { label: string; className: string }> = {
  ACTIVE: { label: "Hoạt động", className: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200" },
  SUSPENDED: { label: "Tạm ngưng", className: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200" },
  TERMINATED: { label: "Chấm dứt", className: "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200" },
  PENDING: { label: "Chờ kích hoạt", className: "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200" },
  LOCKED: { label: "Bị khoá", className: "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200" },
  DISABLED: { label: "Vô hiệu", className: "bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-400" },
};

interface StatusBadgeProps {
  status: Status;
  className?: string;
}

export function StatusBadge({ status, className }: StatusBadgeProps) {
  const config = STATUS_CONFIG[status] ?? { label: status, className: "" };
  return (
    <Badge
      variant="secondary"
      className={cn("text-xs font-medium", config.className, className)}
    >
      {config.label}
    </Badge>
  );
}
